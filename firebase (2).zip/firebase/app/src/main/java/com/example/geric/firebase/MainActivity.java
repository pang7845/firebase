package com.example.geric.firebase;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button button;
    EditText LastN, FirstN;
    TextView top, bottom;
    ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        top=findViewById(R.id.textView2);
        bottom=findViewById(R.id.textView);
        LastN=findViewById(R.id.LastN);
        Log.d("abcd", "UH OHS1");
        FirstN=findViewById(R.id.FirstN);
        Log.d("abcd", "UH OHS2");
        button=findViewById(R.id.button);
        Log.d("abcd", "UH OHS3");
        DatabaseReference main= FirebaseDatabase.getInstance().getReference();
        DatabaseReference mDatabase=main.child("People");
        Log.d("abcd", "UH OHS7");
        mDatabase.addValueEventListener(new ValueEventListener() { //Whole method is a problem
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<ArrayList<String>> finalList = new ArrayList<ArrayList<String>>();
                Log.d("abcd", "UH OHS4");
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    ArrayList<String> person = new ArrayList<>();
                    String official = ds.child("A").getValue(String.class);
                    String OSIS = ds.child("B").getValue(String.class);
                    String Last = ds.child("C").getValue(String.class);
                    String First = ds.child("D").getValue(String.class);
                    String Geometry= ds.child("E").getValue(String.class);
                    String CFA = ds.child("F").getValue(String.class);
                    String Al1= ds.child("G").getValue(String.class);
                    String Al2= ds.child("H").getValue(String.class);
                    String Precalculus= ds.child("I").getValue(String.class);
                    person.add(0,Precalculus);
                    person.add(0,Al2);
                    person.add(0,Al1);
                    person.add(0,CFA);
                    person.add(0,Geometry);
                    person.add(0,First);
                    person.add(0,Last);
                    person.add(0,OSIS);
                    person.add(0,official);
                    Log.d("abcd", official + " / " + OSIS  + " / " + Last+ " / " +First+ " / " +Geometry);
                    finalList.add(person);
                }
                list=finalList;
                for(ArrayList<String> x: finalList){
                    Log.d("abcd", x.get(0));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        Log.d("abcd", "UH OHS45ter");

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("abcd", "UH OHS45");
                String f = FirstN.getText().toString();
                String l = LastN.getText().toString();
                String summary = "";
                for(int i=1;i<list.size();i++){
                    if(f.toLowerCase().equals(list.get(i).get(3).toLowerCase())&&l.toLowerCase().equals(list.get(i).get(2).toLowerCase())){
                    for(int j=4;j<list.get(i).size();j++){
                        if (list.get(i).get(j).length()<2){
                            break;
                        }
                        summary+=list.get(1).get(j)+" "+list.get(i).get(j)+" ";
                    }

                    break;}
                } bottom.setText(summary);

            }
        });



    }
}
